// This is js for moveing our strings:

var typed = new Typed('#element', {
  strings: ["Web Developer!", "Web Designer!", "Front-end Developer!"],
  typeSpeed: 80,
  loop: true,
});

// This code for will give alert , When click on submit button:

document.querySelector(".ved").addEventListener("click", function () {
  alert("Thank you! Your request has been submited");
})

// Hamburger icon, when screen width 600px then show the hamburger icon

let ul=document.querySelector("ul")
let icon=document.querySelector(".icon")

icon.addEventListener("click",()=>{

  ul.classList.toggle("show")

  if(ul.className==="show"){
    document.querySelector("#bar").className="ri-close-line"
  }
  else{
    document.querySelector("#bar").className="ri-menu-3-line"
  }
})

